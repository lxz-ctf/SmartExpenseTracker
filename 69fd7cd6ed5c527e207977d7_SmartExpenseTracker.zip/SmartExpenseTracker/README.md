# 智能记账助手

一款基于AI的安卓记账App，支持截图自动识别金额、订阅管理和月度统计。

## ✨ 功能特性

- 🤖 **AI截图识别** - 截图后自动弹出记账提示，使用AI识别金额
- 💰 **智能记账** - 快速记录支出，支持手动修改金额
- 📊 **月度统计** - 柱状图和饼图展示支出趋势
- 🔄 **订阅管理** - 管理包年/包月订阅，自动均摊到每日支出
- 🔔 **月末提醒** - 每月最后一天推送支出汇总通知
- 🎨 **Material You** - 支持动态取色和暗黑模式

## 📱 安装方法

### 方式一：下载Release APK（推荐）

1. 点击页面右侧的 **Releases**
2. 下载最新版本的APK文件
3. 在手机上安装即可

### 方式二：自行构建

```bash
# 克隆仓库
git clone https://github.com/你的用户名/SmartExpenseTracker.git
cd SmartExpenseTracker

# 构建Debug版本
./gradlew assembleDebug

# 构建Release版本
./gradlew assembleRelease
```

构建完成后，APK文件位于：
- Debug: `app/build/outputs/apk/debug/app-debug.apk`
- Release: `app/build/outputs/apk/release/app-release-unsigned.apk`

## 🔧 首次使用配置

1. **开启权限**
   - 存储权限（读取截图）
   - 通知权限
   - 悬浮窗权限（在设置中申请）

2. **配置AI API**（可选但推荐）
   - 打开App → 设置 → AI API设置
   - 输入你的API密钥
   - 默认使用OpenAI格式，支持任何兼容的API服务

   支持的API格式：
   - OpenAI: `https://api.openai.com/v1`
   - 自定义代理: 填入你的代理地址

3. **开启截图监听**
   - 设置中开启"截图监听"开关
   - 建议关闭电池优化以保持后台运行

## 📝 使用说明

### 截图记账
1. 在任何界面截图
2. App会自动弹出悬浮窗
3. 确认或修改金额后点击"确认记账"

### 添加订阅
1. 进入"订阅"页面
2. 点击右下角+按钮
3. 填写订阅名称、金额、时长和开始日期
4. 系统会自动计算每日均摊费用

### 查看统计
- 进入"统计"页面查看月度趋势和支出构成
- 支持查看历史月份数据

## 🛠 技术栈

- **语言**: Kotlin
- **架构**: MVVM + Repository
- **数据库**: Room
- **网络**: Retrofit + OkHttp
- **图表**: MPAndroidChart
- **UI**: Material Design 3

## 📄 开源协议

MIT License
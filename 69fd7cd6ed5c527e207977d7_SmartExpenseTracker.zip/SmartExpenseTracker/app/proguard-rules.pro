# ProGuard rules
# Keep Room entities
-keep class com.example.smartexpensetracker.data.model.** { *; }
# Keep Retrofit models
-keep class com.example.smartexpensetracker.ocr.** { *; }
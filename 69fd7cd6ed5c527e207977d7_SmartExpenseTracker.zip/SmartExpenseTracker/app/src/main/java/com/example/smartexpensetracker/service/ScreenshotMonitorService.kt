package com.example.smartexpensetracker.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.smartexpensetracker.R
import com.example.smartexpensetracker.ui.main.MainActivity
import com.example.smartexpensetracker.utils.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

class ScreenshotMonitorService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var contentObserver: ContentObserver? = null
    private var lastScreenshotPath: String? = null
    private var lastScreenshotTime: Long = 0
    private val debounceTime = 2000L // 2 seconds debounce

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "ScreenshotMonitorService created")
        startForeground(NOTIFICATION_ID, createNotification())
        registerScreenshotObserver()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "ScreenshotMonitorService started")
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "ScreenshotMonitorService destroyed")
        contentObserver?.let {
            contentResolver.unregisterContentObserver(it)
        }
        serviceScope.cancel()
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, NotificationHelper.CHANNEL_SERVICE)
            .setContentTitle("智能记账助手")
            .setContentText("正在监听截图...")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun registerScreenshotObserver() {
        val screenshotUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

        contentObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                super.onChange(selfChange, uri)
                uri?.let { handleScreenshotChange(it) }
            }
        }

        contentResolver.registerContentObserver(screenshotUri, true, contentObserver!!)
    }

    private fun handleScreenshotChange(uri: Uri) {
        serviceScope.launch {
            try {
                // Debounce to avoid multiple triggers
                val currentTime = System.currentTimeMillis()
                if (currentTime - lastScreenshotTime < debounceTime) {
                    return@launch
                }
                lastScreenshotTime = currentTime

                // Query the screenshot path
                val projection = arrayOf(
                    MediaStore.Images.Media.DATA,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.DATE_ADDED
                )

                contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val pathIndex = cursor.getColumnIndex(MediaStore.Images.Media.DATA)
                        val nameIndex = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)

                        if (pathIndex >= 0 && nameIndex >= 0) {
                            val path = cursor.getString(pathIndex)
                            val name = cursor.getString(nameIndex)

                            // Check if it's a screenshot
                            if (isScreenshot(name, path)) {
                                Log.d(TAG, "Screenshot detected: $path")
                                
                                // Avoid duplicate processing
                                if (path != lastScreenshotPath) {
                                    lastScreenshotPath = path
                                    delay(500) // Wait for file to be fully written
                                    showFloatingWindow(path)
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error handling screenshot change", e)
            }
        }
    }

    private fun isScreenshot(name: String, path: String): Boolean {
        val screenshotPatterns = listOf(
            "screenshot", "screen_shot", "screen-shot", "screencapture",
            "screen_capture", "screen-capture", "截图", "截屏"
        )

        val lowerName = name.lowercase()
        val lowerPath = path.lowercase()

        return screenshotPatterns.any { pattern ->
            lowerName.contains(pattern) || lowerPath.contains(pattern)
        }
    }

    private fun showFloatingWindow(screenshotPath: String) {
        val intent = Intent(this, FloatingWindowService::class.java).apply {
            putExtra(FloatingWindowService.EXTRA_SCREENSHOT_PATH, screenshotPath)
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    companion object {
        private const val TAG = "ScreenshotMonitor"
        private const val NOTIFICATION_ID = 1001

        fun startService(context: Context) {
            val intent = Intent(context, ScreenshotMonitorService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            context.stopService(Intent(context, ScreenshotMonitorService::class.java))
        }
    }
}
package com.example.smartexpensetracker.ui.expense

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.smartexpensetracker.R
import com.example.smartexpensetracker.data.database.AppDatabase
import com.example.smartexpensetracker.data.model.Expense
import com.example.smartexpensetracker.data.repository.ExpenseRepository
import com.example.smartexpensetracker.databinding.FragmentExpenseListBinding
import com.example.smartexpensetracker.utils.DateUtils
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

class ExpenseListFragment : Fragment() {

    private var _binding: FragmentExpenseListBinding? = null
    private val binding get() = _binding!!

    private val viewModel: ExpenseViewModel by viewModels {
        ExpenseViewModel.Factory(
            ExpenseRepository(AppDatabase.getDatabase(requireContext()).expenseDao())
        )
    }

    private lateinit var expenseAdapter: ExpenseAdapter
    private var currentYearMonth = YearMonth.now()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentExpenseListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupRecyclerView()
        setupMonthNavigation()
        setupSwipeToDelete()
        observeExpenses()
        observeMonthlySummary()
        
        viewModel.loadExpensesForMonth(currentYearMonth)
    }

    private fun setupRecyclerView() {
        expenseAdapter = ExpenseAdapter(
            onItemClick = { expense ->
                // Navigate to detail/edit
            },
            onItemLongClick = { expense ->
                showDeleteConfirmation(expense)
                true
            }
        )

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = expenseAdapter
            layoutAnimation = AnimationUtils.loadLayoutAnimation(context, R.anim.layout_animation_fall_down)
        }
    }

    private fun setupMonthNavigation() {
        binding.apply {
            btnPreviousMonth.setOnClickListener {
                currentYearMonth = currentYearMonth.minusMonths(1)
                updateMonthDisplay()
                viewModel.loadExpensesForMonth(currentYearMonth)
            }

            btnNextMonth.setOnClickListener {
                if (currentYearMonth < YearMonth.now()) {
                    currentYearMonth = currentYearMonth.plusMonths(1)
                    updateMonthDisplay()
                    viewModel.loadExpensesForMonth(currentYearMonth)
                }
            }

            updateMonthDisplay()
        }
    }

    private fun updateMonthDisplay() {
        binding.tvCurrentMonth.text = DateUtils.formatMonth(currentYearMonth)
        binding.btnNextMonth.isEnabled = currentYearMonth < YearMonth.now()
        binding.btnNextMonth.alpha = if (currentYearMonth < YearMonth.now()) 1f else 0.3f
    }

    private fun setupSwipeToDelete() {
        val swipeHandler = object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean = false

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                val expense = expenseAdapter.getItem(position)
                
                viewModel.deleteExpense(expense)
                
                Snackbar.make(binding.root, "已删除 ¥${expense.amount}", Snackbar.LENGTH_LONG)
                    .setAction("撤销") {
                        viewModel.restoreExpense(expense)
                    }
                    .show()
            }
        }

        ItemTouchHelper(swipeHandler).attachToRecyclerView(binding.recyclerView)
    }

    private fun observeExpenses() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.expenses.collectLatest { expenses ->
                    expenseAdapter.submitList(expenses) {
                        binding.recyclerView.scheduleLayoutAnimation()
                    }
                    updateEmptyState(expenses.isEmpty())
                }
            }
        }
    }

    private fun observeMonthlySummary() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.monthlySummary.collectLatest { summary ->
                    summary?.let {
                        binding.tvTotalAmount.text = String.format("¥%.2f", it.totalAmount)
                        binding.tvExpenseCount.text = "${it.expenseCount} 笔"
                    }
                }
            }
        }
    }

    private fun updateEmptyState(isEmpty: Boolean) {
        binding.apply {
            if (isEmpty) {
                recyclerView.visibility = View.GONE
                emptyState.visibility = View.VISIBLE
            } else {
                recyclerView.visibility = View.VISIBLE
                emptyState.visibility = View.GONE
            }
        }
    }

    private fun showDeleteConfirmation(expense: Expense) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("删除记账")
            .setMessage("确定要删除这笔 ¥${expense.amount} 的支出记录吗？")
            .setPositiveButton("删除") { _, _ ->
                viewModel.deleteExpense(expense)
            }
            .setNegativeButton("取消", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
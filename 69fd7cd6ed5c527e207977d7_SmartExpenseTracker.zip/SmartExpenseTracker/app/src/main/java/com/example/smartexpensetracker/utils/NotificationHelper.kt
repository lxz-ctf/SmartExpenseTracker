package com.example.smartexpensetracker.utils

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.example.smartexpensetracker.R
import com.example.smartexpensetracker.ui.main.MainActivity
import java.time.YearMonth

object NotificationHelper {

    const val CHANNEL_SCREENSHOT = "screenshot_channel"
    const val CHANNEL_MONTHLY = "monthly_channel"
    const val CHANNEL_SERVICE = "service_channel"

    private const val NOTIFICATION_ID_MONTHLY = 3001

    fun showMonthlySummaryNotification(
        context: Context,
        yearMonth: YearMonth,
        totalAmount: Double,
        expenseCount: Int
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            putExtra("navigate_to", "statistics")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_MONTHLY)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("${yearMonth.year}年${yearMonth.monthValue}月支出汇总")
            .setContentText("本月共支出 ¥${String.format("%.2f", totalAmount)}，共 $expenseCount 笔消费")
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText("本月共支出 ¥${String.format("%.2f", totalAmount)}，共 $expenseCount 笔消费\n点击查看详情"))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID_MONTHLY, notification)
    }

    fun showScreenshotNotification(context: Context, screenshotPath: String) {
        val intent = Intent(context, MainActivity::class.java).apply {
            putExtra("screenshot_path", screenshotPath)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_SCREENSHOT)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("检测到截图")
            .setContentText("是否将此截图纳入记账？")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    }
}
package com.example.smartexpensetracker.ui.main

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.animation.OvershootInterpolator
import androidx.activity.OnBackPressedDispatcher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.animation.doOnEnd
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import androidx.core.view.updatePadding
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.example.smartexpensetracker.R
import com.example.smartexpensetracker.databinding.ActivityMainBinding
import com.example.smartexpensetracker.service.DailyAmortizationWorker
import com.example.smartexpensetracker.service.MonthlyNotificationReceiver
import com.example.smartexpensetracker.service.ScreenshotMonitorService
import com.example.smartexpensetracker.utils.PreferenceManager
import com.google.android.material.transition.MaterialElevationScale
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController
    private lateinit var preferenceManager: PreferenceManager
    private val viewModel: MainViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        handlePermissionResults(permissions)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        
        WindowCompat.setDecorFitsSystemWindows(window, false)
        
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        preferenceManager = PreferenceManager(this)

        setupEdgeToEdge()
        setupNavigation()
        setupFab()
        checkPermissions()
        startServices()
        
        if (preferenceManager.isFirstLaunch()) {
            showWelcomeDialog()
            preferenceManager.setFirstLaunchCompleted()
        }
    }

    private fun setupEdgeToEdge() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            binding.appBar.updatePadding(top = systemBars.top)
            binding.bottomNav.updatePadding(bottom = systemBars.bottom)
            insets
        }
    }

    private fun setupNavigation() {
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController
        
        binding.bottomNav.setupWithNavController(navController)
        
        navController.addOnDestinationChangedListener { _, destination, _ ->
            when (destination.id) {
                R.id.expenseListFragment, R.id.statisticsFragment, R.id.subscriptionFragment -> {
                    showBottomNav()
                }
                else -> hideBottomNav()
            }
        }
    }

    private fun setupFab() {
        binding.fabAdd.setOnClickListener { view ->
            // Animate FAB
            view.animate()
                .scaleX(0.8f)
                .scaleY(0.8f)
                .setDuration(100)
                .withEndAction {
                    view.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(150)
                        .setInterpolator(OvershootInterpolator())
                        .start()
                }
                .start()

            // Navigate to add expense
            navController.navigate(R.id.action_global_addExpenseFragment)
        }
    }

    private fun showBottomNav() {
        binding.bottomNav.isVisible = true
        binding.bottomNav.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(200)
            .start()
        
        binding.fabAdd.isVisible = true
        binding.fabAdd.animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(200)
            .setInterpolator(OvershootInterpolator())
            .start()
    }

    private fun hideBottomNav() {
        binding.bottomNav.animate()
            .translationY(binding.bottomNav.height.toFloat())
            .alpha(0f)
            .setDuration(200)
            .withEndAction { binding.bottomNav.isVisible = false }
            .start()
        
        binding.fabAdd.animate()
            .scaleX(0f)
            .scaleY(0f)
            .alpha(0f)
            .setDuration(200)
            .withEndAction { binding.fabAdd.isVisible = false }
            .start()
    }

    private fun checkPermissions() {
        val permissions = mutableListOf<String>()
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val permissionsToRequest = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (permissionsToRequest.isNotEmpty()) {
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }

    private fun handlePermissionResults(permissions: Map<String, Boolean>) {
        val allGranted = permissions.values.all { it }
        if (!allGranted) {
            AlertDialog.Builder(this)
                .setTitle("需要权限")
                .setMessage("为了正常监听截图，需要存储权限。请在设置中开启。")
                .setPositiveButton("去设置") { _, _ ->
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.fromParts("package", packageName, null)
                    }
                    startActivity(intent)
                }
                .setNegativeButton("取消", null)
                .show()
        }
    }

    private fun startServices() {
        if (preferenceManager.isScreenshotMonitoringEnabled()) {
            ScreenshotMonitorService.startService(this)
        }
        
        if (preferenceManager.isMonthlyNotificationEnabled()) {
            MonthlyNotificationReceiver.scheduleMonthlyNotification(this)
        }
        
        DailyAmortizationWorker.schedule(this)
    }

    private fun showWelcomeDialog() {
        AlertDialog.Builder(this)
            .setTitle("欢迎使用智能记账助手")
            .setMessage("本应用可以：\n\n" +
                    "• 自动检测截图并识别金额\n" +
                    "• 管理包年/包月订阅\n" +
                    "• 自动均摊订阅费用\n" +
                    "• 月末发送支出汇总\n\n" +
                    "请先设置您的AI API密钥以获得最佳体验。")
            .setPositiveButton("去设置") { _, _ ->
                navController.navigate(R.id.settingsFragment)
            }
            .setNegativeButton("稍后再说", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}
package com.example.smartexpensetracker.ui.subscription

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.smartexpensetracker.R
import com.example.smartexpensetracker.data.database.AppDatabase
import com.example.smartexpensetracker.data.model.Subscription
import com.example.smartexpensetracker.data.repository.SubscriptionRepository
import com.example.smartexpensetracker.databinding.FragmentSubscriptionBinding
import com.example.smartexpensetracker.databinding.DialogAddSubscriptionBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.Calendar

class SubscriptionFragment : Fragment() {

    private var _binding: FragmentSubscriptionBinding? = null
    private val binding get() = _binding!!

    private val viewModel: SubscriptionViewModel by viewModels {
        SubscriptionViewModel.Factory(
            SubscriptionRepository(AppDatabase.getDatabase(requireContext()).subscriptionDao())
        )
    }

    private lateinit var subscriptionAdapter: SubscriptionAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSubscriptionBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupRecyclerView()
        setupFab()
        setupSwipeToDelete()
        observeSubscriptions()
    }

    private fun setupRecyclerView() {
        subscriptionAdapter = SubscriptionAdapter(
            onItemClick = { subscription ->
                showSubscriptionDetails(subscription)
            }
        )

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = subscriptionAdapter
            layoutAnimation = AnimationUtils.loadLayoutAnimation(context, R.anim.layout_animation_fall_down)
        }
    }

    private fun setupFab() {
        binding.fabAdd.setOnClickListener {
            showAddSubscriptionDialog()
        }
    }

    private fun setupSwipeToDelete() {
        val swipeHandler = object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean = false

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                val subscription = subscriptionAdapter.getItem(position)
                
                viewModel.deleteSubscription(subscription)
                
                Snackbar.make(binding.root, "已删除 ${subscription.name}", Snackbar.LENGTH_LONG)
                    .setAction("撤销") {
                        viewModel.addSubscription(subscription)
                    }
                    .show()
            }
        }

        ItemTouchHelper(swipeHandler).attachToRecyclerView(binding.recyclerView)
    }

    private fun observeSubscriptions() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.subscriptions.collectLatest { subscriptions ->
                    subscriptionAdapter.submitList(subscriptions) {
                        binding.recyclerView.scheduleLayoutAnimation()
                    }
                    updateEmptyState(subscriptions.isEmpty())
                }
            }
        }
    }

    private fun updateEmptyState(isEmpty: Boolean) {
        binding.apply {
            if (isEmpty) {
                recyclerView.visibility = View.GONE
                emptyState.visibility = View.VISIBLE
            } else {
                recyclerView.visibility = View.VISIBLE
                emptyState.visibility = View.GONE
            }
        }
    }

    private fun showAddSubscriptionDialog() {
        val dialogBinding = DialogAddSubscriptionBinding.inflate(layoutInflater)
        
        var selectedDate = LocalDate.now()
        
        dialogBinding.apply {
            btnSelectDate.setOnClickListener {
                val calendar = Calendar.getInstance()
                DatePickerDialog(
                    requireContext(),
                    { _, year, month, day ->
                        selectedDate = LocalDate.of(year, month + 1, day)
                        tvSelectedDate.text = "开始日期: ${selectedDate}"
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
                ).show()
            }
            
            tvSelectedDate.text = "开始日期: ${selectedDate}"
        }

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("添加订阅")
            .setView(dialogBinding.root)
            .setPositiveButton("添加") { _, _ ->
                val name = dialogBinding.etName.text.toString()
                val amount = dialogBinding.etAmount.text.toString().toDoubleOrNull() ?: 0.0
                val duration = dialogBinding.etDuration.text.toString().toIntOrNull() ?: 12
                
                if (name.isNotBlank() && amount > 0) {
                    val subscription = Subscription(
                        name = name,
                        amount = amount,
                        startDate = selectedDate,
                        durationMonths = duration
                    )
                    viewModel.addSubscription(subscription)
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showSubscriptionDetails(subscription: Subscription) {
        val message = """
            订阅名称: ${subscription.name}
            总金额: ¥${String.format("%.2f", subscription.amount)}
            开始日期: ${subscription.startDate}
            结束日期: ${subscription.endDate}
            持续时长: ${subscription.durationMonths} 个月
            每日均摊: ¥${String.format("%.2f", subscription.dailyAmount)}
            状态: ${if (subscription.isActive) "活跃" else "已停用"}
        """.trimIndent()

        MaterialAlertDialogBuilder(requireContext())
            .setTitle(subscription.name)
            .setMessage(message)
            .setPositiveButton("确定", null)
            .setNegativeButton("删除") { _, _ ->
                viewModel.deleteSubscription(subscription)
            }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
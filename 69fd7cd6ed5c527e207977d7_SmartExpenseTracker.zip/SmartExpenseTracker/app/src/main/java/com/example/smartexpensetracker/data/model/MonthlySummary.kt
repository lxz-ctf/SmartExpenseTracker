package com.example.smartexpensetracker.data.model

import java.time.LocalDate
import java.time.YearMonth

data class MonthlySummary(
    val yearMonth: YearMonth,
    val totalAmount: Double,
    val expenseCount: Int,
    val subscriptionAmount: Double,
    val regularAmount: Double
) {
    val averageDaily: Double
        get() = totalAmount / yearMonth.lengthOfMonth()

    companion object {
        fun empty(yearMonth: YearMonth): MonthlySummary {
            return MonthlySummary(
                yearMonth = yearMonth,
                totalAmount = 0.0,
                expenseCount = 0,
                subscriptionAmount = 0.0,
                regularAmount = 0.0
            )
        }
    }
}
package com.example.smartexpensetracker.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDate
import java.time.temporal.ChronoUnit

@Entity(tableName = "subscriptions")
data class Subscription(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val amount: Double,
    val startDate: LocalDate,
    val durationMonths: Int,
    val isActive: Boolean = true,
    val createdAt: LocalDate = LocalDate.now()
) {
    val endDate: LocalDate
        get() = startDate.plusMonths(durationMonths.toLong())

    val dailyAmount: Double
        get() = amount / (durationMonths * 30.0)

    val totalDays: Long
        get() = ChronoUnit.DAYS.between(startDate, endDate)

    fun isActiveOn(date: LocalDate): Boolean {
        return isActive && !date.isBefore(startDate) && !date.isAfter(endDate)
    }

    fun getRemainingDays(date: LocalDate): Long {
        return ChronoUnit.DAYS.between(date, endDate).coerceAtLeast(0)
    }
}
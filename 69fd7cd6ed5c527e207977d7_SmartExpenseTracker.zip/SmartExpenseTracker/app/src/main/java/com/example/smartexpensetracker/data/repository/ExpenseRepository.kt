package com.example.smartexpensetracker.data.repository

import com.example.smartexpensetracker.data.database.ExpenseDao
import com.example.smartexpensetracker.data.model.Expense
import com.example.smartexpensetracker.data.model.MonthlySummary
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.TemporalAdjusters

class ExpenseRepository(private val expenseDao: ExpenseDao) {

    fun getAllExpenses(): Flow<List<Expense>> = expenseDao.getAllExpenses()

    fun getExpensesByDate(date: LocalDate): Flow<List<Expense>> = expenseDao.getExpensesByDate(date)

    fun getExpensesByMonth(yearMonth: YearMonth): Flow<List<Expense>> {
        val startDate = yearMonth.atDay(1)
        val endDate = yearMonth.atEndOfMonth()
        return expenseDao.getExpensesBetweenDates(startDate, endDate)
    }

    suspend fun getMonthlySummary(yearMonth: YearMonth): MonthlySummary {
        val startDate = yearMonth.atDay(1)
        val endDate = yearMonth.atEndOfMonth()

        val expenses = expenseDao.getExpensesBetweenDatesSync(startDate, endDate)
        val totalAmount = expenses.sumOf { it.amount }
        val subscriptionAmount = expenses.filter { it.isAmortization }.sumOf { it.amount }
        val regularAmount = totalAmount - subscriptionAmount

        return MonthlySummary(
            yearMonth = yearMonth,
            totalAmount = totalAmount,
            expenseCount = expenses.size,
            subscriptionAmount = subscriptionAmount,
            regularAmount = regularAmount
        )
    }

    suspend fun insertExpense(expense: Expense): Long {
        return expenseDao.insertExpense(expense)
    }

    suspend fun insertExpenses(expenses: List<Expense>) {
        expenseDao.insertExpenses(expenses)
    }

    suspend fun updateExpense(expense: Expense) {
        expenseDao.updateExpense(expense)
    }

    suspend fun deleteExpense(expense: Expense) {
        expenseDao.deleteExpense(expense)
    }

    suspend fun deleteExpenseById(expenseId: Long) {
        expenseDao.deleteExpenseById(expenseId)
    }

    suspend fun getExpenseById(expenseId: Long): Expense? {
        return expenseDao.getExpenseById(expenseId)
    }

    suspend fun getTotalAmountForToday(): Double {
        return expenseDao.getTotalAmountForDate(LocalDate.now()) ?: 0.0
    }

    suspend fun getTotalAmountForMonth(yearMonth: YearMonth): Double {
        val startDate = yearMonth.atDay(1)
        val endDate = yearMonth.atEndOfMonth()
        return expenseDao.getTotalAmountBetweenDates(startDate, endDate) ?: 0.0
    }
}
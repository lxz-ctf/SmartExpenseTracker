package com.example.smartexpensetracker.ui.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.smartexpensetracker.data.model.MonthlySummary
import com.example.smartexpensetracker.data.repository.ExpenseRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.YearMonth

class MainViewModel(private val expenseRepository: ExpenseRepository) : ViewModel() {

    private val _currentMonthSummary = MutableStateFlow<MonthlySummary?>(null)
    val currentMonthSummary: StateFlow<MonthlySummary?> = _currentMonthSummary.asStateFlow()

    init {
        loadCurrentMonthSummary()
    }

    private fun loadCurrentMonthSummary() {
        viewModelScope.launch {
            val summary = expenseRepository.getMonthlySummary(YearMonth.now())
            _currentMonthSummary.value = summary
        }
    }

    fun refreshSummary() {
        loadCurrentMonthSummary()
    }
}
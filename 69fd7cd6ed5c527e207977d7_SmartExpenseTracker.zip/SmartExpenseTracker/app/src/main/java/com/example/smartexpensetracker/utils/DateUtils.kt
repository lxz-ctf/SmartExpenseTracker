package com.example.smartexpensetracker.utils

import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

object DateUtils {

    private val dateFormatter = DateTimeFormatter.ofPattern("yyyy年MM月dd日", Locale.CHINA)
    private val monthFormatter = DateTimeFormatter.ofPattern("yyyy年MM月", Locale.CHINA)
    private val shortDateFormatter = DateTimeFormatter.ofPattern("MM/dd", Locale.CHINA)

    fun formatDate(date: LocalDate): String = date.format(dateFormatter)
    
    fun formatMonth(yearMonth: YearMonth): String = yearMonth.format(monthFormatter)
    
    fun formatShortDate(date: LocalDate): String = date.format(shortDateFormatter)

    fun formatDuration(startDate: LocalDate, endDate: LocalDate): String {
        val days = ChronoUnit.DAYS.between(startDate, endDate)
        val months = ChronoUnit.MONTHS.between(startDate, endDate)
        
        return when {
            months >= 12 -> "${months / 12}年${months % 12}个月"
            months > 0 -> "$months 个月"
            days > 0 -> "$days 天"
            else -> "今天到期"
        }
    }

    fun getDaysRemaining(endDate: LocalDate): Long {
        return ChronoUnit.DAYS.between(LocalDate.now(), endDate).coerceAtLeast(0)
    }

    fun isToday(date: LocalDate): Boolean = date == LocalDate.now()
    
    fun isThisMonth(yearMonth: YearMonth): Boolean = yearMonth == YearMonth.now()
}
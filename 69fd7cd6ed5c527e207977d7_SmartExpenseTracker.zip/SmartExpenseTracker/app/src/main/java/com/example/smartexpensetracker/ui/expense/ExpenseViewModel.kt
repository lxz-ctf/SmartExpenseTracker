package com.example.smartexpensetracker.ui.expense

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.smartexpensetracker.data.model.Expense
import com.example.smartexpensetracker.data.model.MonthlySummary
import com.example.smartexpensetracker.data.repository.ExpenseRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.YearMonth

class ExpenseViewModel(private val expenseRepository: ExpenseRepository) : ViewModel() {

    private val _expenses = MutableStateFlow<List<Expense>>(emptyList())
    val expenses: StateFlow<List<Expense>> = _expenses.asStateFlow()

    private val _monthlySummary = MutableStateFlow<MonthlySummary?>(null)
    val monthlySummary: StateFlow<MonthlySummary?> = _monthlySummary.asStateFlow()

    fun loadExpensesForMonth(yearMonth: YearMonth) {
        viewModelScope.launch {
            expenseRepository.getExpensesByMonth(yearMonth).collect {
                _expenses.value = it
            }
        }
        
        viewModelScope.launch {
            _monthlySummary.value = expenseRepository.getMonthlySummary(yearMonth)
        }
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch {
            expenseRepository.deleteExpense(expense)
        }
    }

    fun restoreExpense(expense: Expense) {
        viewModelScope.launch {
            expenseRepository.insertExpense(expense)
        }
    }

    class Factory(private val expenseRepository: ExpenseRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(ExpenseViewModel::class.java)) {
                return ExpenseViewModel(expenseRepository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
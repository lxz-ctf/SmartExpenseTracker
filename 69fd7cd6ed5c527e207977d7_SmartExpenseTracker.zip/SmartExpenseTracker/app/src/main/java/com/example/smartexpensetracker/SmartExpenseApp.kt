package com.example.smartexpensetracker

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.work.Configuration
import androidx.work.WorkManager
import com.example.smartexpensetracker.utils.NotificationHelper

class SmartExpenseApp : Application(), Configuration.Provider {

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Screenshot detection channel
            val screenshotChannel = NotificationChannel(
                NotificationHelper.CHANNEL_SCREENSHOT,
                "截图检测",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "检测到截图时提醒您记账"
                enableVibration(true)
            }

            // Monthly summary channel
            val monthlyChannel = NotificationChannel(
                NotificationHelper.CHANNEL_MONTHLY,
                "月度账单",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "每月支出汇总通知"
            }

            // Service channel
            val serviceChannel = NotificationChannel(
                NotificationHelper.CHANNEL_SERVICE,
                "后台服务",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "保持截图监听服务运行"
            }

            notificationManager.createNotificationChannels(
                listOf(screenshotChannel, monthlyChannel, serviceChannel)
            )
        }
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()

    companion object {
        lateinit var instance: SmartExpenseApp
            private set
    }
}
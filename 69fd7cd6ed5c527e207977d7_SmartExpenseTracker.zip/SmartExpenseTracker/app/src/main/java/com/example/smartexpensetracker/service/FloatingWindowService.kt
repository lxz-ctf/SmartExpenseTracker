package com.example.smartexpensetracker.service

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.Base64
import android.util.Log
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import com.bumptech.glide.Glide
import com.example.smartexpensetracker.R
import com.example.smartexpensetracker.data.database.AppDatabase
import com.example.smartexpensetracker.data.model.Expense
import com.example.smartexpensetracker.data.repository.ExpenseRepository
import com.example.smartexpensetracker.ocr.AIService
import com.example.smartexpensetracker.utils.PreferenceManager
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import java.io.File

class FloatingWindowService : Service() {

    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var expenseRepository: ExpenseRepository
    private lateinit var aiService: AIService
    private lateinit var preferenceManager: PreferenceManager

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        expenseRepository = ExpenseRepository(AppDatabase.getDatabase(this).expenseDao())
        aiService = AIService()
        preferenceManager = PreferenceManager(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val screenshotPath = intent?.getStringExtra(EXTRA_SCREENSHOT_PATH)
        if (screenshotPath != null) {
            showFloatingWindow(screenshotPath)
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun showFloatingWindow(screenshotPath: String) {
        if (!Settings.canDrawOverlays(this)) {
            // Request permission
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                data = Uri.parse("package:$packageName")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
            stopSelf()
            return
        }

        // Remove existing view if any
        floatingView?.let {
            windowManager.removeView(it)
            floatingView = null
        }

        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.layout_floating_window, null)
        floatingView = view

        // Setup window parameters
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 100
        }

        // Setup views
        val cardView = view.findViewById<CardView>(R.id.cardView)
        val screenshotImage = view.findViewById<ImageView>(R.id.screenshotImage)
        val amountText = view.findViewById<TextView>(R.id.amountText)
        val btnConfirm = view.findViewById<View>(R.id.btnConfirm)
        val btnCancel = view.findViewById<View>(R.id.btnCancel)
        val btnEdit = view.findViewById<View>(R.id.btnEdit)
        val loadingView = view.findViewById<View>(R.id.loadingView)

        // Load screenshot
        Glide.with(this)
            .load(File(screenshotPath))
            .centerCrop()
            .into(screenshotImage)

        // Animate entrance
        cardView.scaleX = 0.8f
        cardView.scaleY = 0.8f
        cardView.alpha = 0f

        windowManager.addView(view, params)

        cardView.animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(300)
            .setInterpolator(OvershootInterpolator())
            .start()

        // Recognize amount
        serviceScope.launch {
            loadingView.visibility = View.VISIBLE
            val amount = recognizeAmount(screenshotPath)
            loadingView.visibility = View.GONE

            amount?.let {
                amountText.text = String.format("¥%.2f", it)
                amountText.tag = it
            } ?: run {
                amountText.text = "未识别到金额"
                amountText.tag = null
            }
        }

        // Button click handlers
        btnConfirm.setOnClickListener {
            val amount = amountText.tag as? Double
            if (amount != null) {
                saveExpense(amount, screenshotPath)
                animateOutAndClose(cardView)
            }
        }

        btnCancel.setOnClickListener {
            animateOutAndClose(cardView)
        }

        btnEdit.setOnClickListener {
            showEditAmountDialog(amountText)
        }

        // Auto close after 30 seconds
        Handler(Looper.getMainLooper()).postDelayed({
            if (floatingView != null) {
                animateOutAndClose(cardView)
            }
        }, 30000)
    }

    private suspend fun recognizeAmount(screenshotPath: String): Double? {
        return withContext(Dispatchers.IO) {
            try {
                val file = File(screenshotPath)
                if (!file.exists()) return@withContext null

                // Check if AI is configured
                val apiKey = preferenceManager.getApiKey()
                if (apiKey.isNullOrBlank()) {
                    // Fallback to regex-based extraction
                    return@withContext null
                }

                // Convert image to base64
                val bitmap = android.graphics.BitmapFactory.decodeFile(screenshotPath)
                val outputStream = ByteArrayOutputStream()
                bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, outputStream)
                val base64Image = Base64.encodeToString(outputStream.toByteArray(), Base64.DEFAULT)

                val config = AIService.AIConfig(
                    apiKey = apiKey,
                    baseUrl = preferenceManager.getApiBaseUrl() ?: "https://api.openai.com/v1",
                    model = preferenceManager.getModel() ?: "gpt-4o-mini"
                )

                when (val result = aiService.recognizeAmount(base64Image, config)) {
                    is AIService.RecognitionResult.Success -> result.amount
                    else -> null
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error recognizing amount", e)
                null
            }
        }
    }

    private fun saveExpense(amount: Double, screenshotPath: String) {
        serviceScope.launch {
            val expense = Expense.fromScreenshot(
                amount = amount,
                screenshotPath = screenshotPath,
                description = "截图记账"
            )
            expenseRepository.insertExpense(expense)
        }
    }

    private fun showEditAmountDialog(amountText: View) {
        // Create a simple edit dialog
        val editView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_amount, null)
        val editText = editView.findViewById<android.widget.EditText>(R.id.editAmount)
        
        val currentAmount = amountText.tag as? Double
        editText.setText(currentAmount?.toString() ?: "")

        val dialog = android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog)
            .setTitle("修改金额")
            .setView(editView)
            .setPositiveButton("确定") { _, _ ->
                val newAmount = editText.text.toString().toDoubleOrNull()
                if (newAmount != null) {
                    (amountText as TextView).text = String.format("¥%.2f", newAmount)
                    amountText.tag = newAmount
                }
            }
            .setNegativeButton("取消", null)
            .create()

        dialog.window?.setType(if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_SYSTEM_DIALOG
        })
        dialog.show()
    }

    private fun animateOutAndClose(view: View) {
        view.animate()
            .scaleX(0.8f)
            .scaleY(0.8f)
            .alpha(0f)
            .setDuration(200)
            .setInterpolator(DecelerateInterpolator())
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    closeFloatingWindow()
                }
            })
            .start()
    }

    private fun closeFloatingWindow() {
        floatingView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                Log.e(TAG, "Error removing view", e)
            }
            floatingView = null
        }
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        floatingView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    companion object {
        private const val TAG = "FloatingWindow"
        const val EXTRA_SCREENSHOT_PATH = "screenshot_path"
    }
}
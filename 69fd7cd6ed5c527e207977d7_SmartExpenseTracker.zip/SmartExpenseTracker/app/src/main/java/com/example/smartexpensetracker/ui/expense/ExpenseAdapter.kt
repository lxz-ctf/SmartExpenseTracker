package com.example.smartexpensetracker.ui.expense

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.smartexpensetracker.R
import com.example.smartexpensetracker.data.model.Expense
import com.example.smartexpensetracker.databinding.ItemExpenseBinding
import com.example.smartexpensetracker.utils.DateUtils
import java.io.File

class ExpenseAdapter(
    private val onItemClick: (Expense) -> Unit,
    private val onItemLongClick: (Expense) -> Boolean
) : ListAdapter<Expense, ExpenseAdapter.ExpenseViewHolder>(ExpenseDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExpenseViewHolder {
        val binding = ItemExpenseBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ExpenseViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ExpenseViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    fun getItem(position: Int): Expense = currentList[position]

    inner class ExpenseViewHolder(
        private val binding: ItemExpenseBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onItemClick(getItem(position))
                }
            }
            
            binding.root.setOnLongClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onItemLongClick(getItem(position))
                } else false
            }
        }

        fun bind(expense: Expense) {
            binding.apply {
                tvAmount.text = String.format("¥%.2f", expense.amount)
                tvDate.text = DateUtils.formatShortDate(expense.date)
                tvDescription.text = expense.description ?: "记账"
                
                // Show amortization badge
                if (expense.isAmortization) {
                    badgeAmortization.visibility = View.VISIBLE
                } else {
                    badgeAmortization.visibility = View.GONE
                }

                // Load screenshot thumbnail if available
                if (!expense.screenshotPath.isNullOrBlank()) {
                    val file = File(expense.screenshotPath)
                    if (file.exists()) {
                        ivScreenshot.visibility = View.VISIBLE
                        Glide.with(root.context)
                            .load(file)
                            .centerCrop()
                            .placeholder(R.drawable.ic_image_placeholder)
                            .into(ivScreenshot)
                    } else {
                        ivScreenshot.visibility = View.GONE
                    }
                } else {
                    ivScreenshot.visibility = View.GONE
                }
            }
        }
    }

    class ExpenseDiffCallback : DiffUtil.ItemCallback<Expense>() {
        override fun areItemsTheSame(oldItem: Expense, newItem: Expense): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Expense, newItem: Expense): Boolean {
            return oldItem == newItem
        }
    }
}
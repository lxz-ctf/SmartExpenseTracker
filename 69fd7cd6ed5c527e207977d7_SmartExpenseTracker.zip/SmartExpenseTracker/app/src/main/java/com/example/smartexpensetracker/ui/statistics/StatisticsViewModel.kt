package com.example.smartexpensetracker.ui.statistics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.smartexpensetracker.data.model.Expense
import com.example.smartexpensetracker.data.repository.ExpenseRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.YearMonth

class StatisticsViewModel(private val expenseRepository: ExpenseRepository) : ViewModel() {

    private val _statistics = MutableStateFlow(StatisticsData())
    val statistics: StateFlow<StatisticsData> = _statistics.asStateFlow()

    init {
        loadStatistics()
    }

    private fun loadStatistics() {
        viewModelScope.launch {
            // Load last 6 months of data
            val monthlyData = mutableListOf<Pair<YearMonth, Double>>()
            var totalExpense = 0.0
            var totalTransactions = 0
            var subscriptionExpense = 0.0

            for (i in 5 downTo 0) {
                val yearMonth = YearMonth.now().minusMonths(i.toLong())
                val summary = expenseRepository.getMonthlySummary(yearMonth)
                monthlyData.add(yearMonth to summary.totalAmount)
                
                if (i == 0) { // Current month
                    totalExpense = summary.totalAmount
                    totalTransactions = summary.expenseCount
                    subscriptionExpense = summary.subscriptionAmount
                }
            }

            // Calculate average daily
            val daysInMonth = YearMonth.now().lengthOfMonth()
            val averageDaily = if (daysInMonth > 0) totalExpense / daysInMonth else 0.0

            // Category data (simplified - subscription vs regular)
            val categoryData = mapOf(
                "订阅均摊" to subscriptionExpense,
                "其他支出" to (totalExpense - subscriptionExpense)
            )

            _statistics.value = StatisticsData(
                totalExpense = totalExpense,
                averageDaily = averageDaily,
                totalTransactions = totalTransactions,
                subscriptionExpense = subscriptionExpense,
                monthlyData = monthlyData,
                categoryData = categoryData
            )
        }
    }

    data class StatisticsData(
        val totalExpense: Double = 0.0,
        val averageDaily: Double = 0.0,
        val totalTransactions: Int = 0,
        val subscriptionExpense: Double = 0.0,
        val monthlyData: List<Pair<YearMonth, Double>> = emptyList(),
        val categoryData: Map<String, Double> = emptyMap()
    )

    class Factory(private val expenseRepository: ExpenseRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(StatisticsViewModel::class.java)) {
                return StatisticsViewModel(expenseRepository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
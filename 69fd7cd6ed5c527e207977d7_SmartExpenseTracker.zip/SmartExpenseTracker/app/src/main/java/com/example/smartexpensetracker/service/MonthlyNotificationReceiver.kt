package com.example.smartexpensetracker.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.smartexpensetracker.data.database.AppDatabase
import com.example.smartexpensetracker.data.repository.ExpenseRepository
import com.example.smartexpensetracker.utils.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.util.Calendar

class MonthlyNotificationReceiver : BroadcastReceiver() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onReceive(context: Context, intent: Intent) {
        Log.d(TAG, "Monthly notification triggered")
        
        scope.launch {
            try {
                val repository = ExpenseRepository(AppDatabase.getDatabase(context).expenseDao())
                val lastMonth = YearMonth.now().minusMonths(1)
                val summary = repository.getMonthlySummary(lastMonth)
                
                NotificationHelper.showMonthlySummaryNotification(
                    context,
                    lastMonth,
                    summary.totalAmount,
                    summary.expenseCount
                )
                
                // Schedule next month's notification
                scheduleMonthlyNotification(context)
            } catch (e: Exception) {
                Log.e(TAG, "Error showing monthly notification", e)
            }
        }
    }

    companion object {
        private const val TAG = "MonthlyNotification"
        private const val REQUEST_CODE = 2001

        fun scheduleMonthlyNotification(context: Context) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, MonthlyNotificationReceiver::class.java)
            
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                REQUEST_CODE,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Schedule for the last day of current month at 20:00
            val calendar = Calendar.getInstance().apply {
                set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
                set(Calendar.HOUR_OF_DAY, 20)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
            }

            // If already passed, schedule for next month
            if (calendar.timeInMillis <= System.currentTimeMillis()) {
                calendar.add(Calendar.MONTH, 1)
                calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
            }

            Log.d(TAG, "Scheduling notification for: ${calendar.time}")

            try {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            } catch (e: SecurityException) {
                Log.e(TAG, "Cannot schedule exact alarm", e)
                // Fallback to inexact alarm
                alarmManager.set(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            }
        }

        fun cancelMonthlyNotification(context: Context) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, MonthlyNotificationReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                REQUEST_CODE,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            alarmManager.cancel(pendingIntent)
        }
    }
}
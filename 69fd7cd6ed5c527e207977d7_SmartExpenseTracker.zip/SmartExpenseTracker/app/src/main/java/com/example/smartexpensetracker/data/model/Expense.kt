package com.example.smartexpensetracker.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDate
import java.time.LocalDateTime

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val amount: Double,
    val description: String? = null,
    val screenshotPath: String? = null,
    val date: LocalDate = LocalDate.now(),
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isAmortization: Boolean = false,
    val subscriptionId: Long? = null
) {
    companion object {
        fun fromScreenshot(amount: Double, screenshotPath: String?, description: String? = null): Expense {
            return Expense(
                amount = amount,
                description = description,
                screenshotPath = screenshotPath,
                date = LocalDate.now()
            )
        }
    }
}
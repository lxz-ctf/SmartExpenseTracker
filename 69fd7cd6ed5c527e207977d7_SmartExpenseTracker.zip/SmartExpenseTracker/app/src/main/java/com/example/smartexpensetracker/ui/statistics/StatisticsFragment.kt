package com.example.smartexpensetracker.ui.statistics

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.smartexpensetracker.R
import com.example.smartexpensetracker.data.database.AppDatabase
import com.example.smartexpensetracker.data.repository.ExpenseRepository
import com.example.smartexpensetracker.databinding.FragmentStatisticsBinding
import com.example.smartexpensetracker.utils.DateUtils
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.ValueFormatter
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.time.YearMonth
import java.time.format.DateTimeFormatter

class StatisticsFragment : Fragment() {

    private var _binding: FragmentStatisticsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: StatisticsViewModel by viewModels {
        StatisticsViewModel.Factory(
            ExpenseRepository(AppDatabase.getDatabase(requireContext()).expenseDao())
        )
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentStatisticsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupCharts()
        observeStatistics()
    }

    private fun setupCharts() {
        // Setup bar chart
        binding.barChart.apply {
            description.isEnabled = false
            setDrawGridBackground(false)
            setDrawBarShadow(false)
            setDrawValueAboveBar(true)
            setPinchZoom(false)
            setScaleEnabled(false)
            
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                granularity = 1f
            }
            
            axisLeft.apply {
                setDrawGridLines(true)
                axisMinimum = 0f
            }
            
            axisRight.isEnabled = false
            legend.isEnabled = true
        }

        // Setup pie chart
        binding.pieChart.apply {
            description.isEnabled = false
            isRotationEnabled = true
            isHighlightPerTapEnabled = true
            setUsePercentValues(true)
            setEntryLabelColor(Color.BLACK)
            setEntryLabelTextSize(12f)
            legend.isEnabled = true
        }
    }

    private fun observeStatistics() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.statistics.collectLatest { stats ->
                    updateSummary(stats)
                    updateBarChart(stats.monthlyData)
                    updatePieChart(stats.categoryData)
                }
            }
        }
    }

    private fun updateSummary(stats: StatisticsViewModel.StatisticsData) {
        binding.apply {
            tvTotalExpense.text = String.format("¥%.2f", stats.totalExpense)
            tvAverageDaily.text = String.format("¥%.2f", stats.averageDaily)
            tvTotalTransactions.text = stats.totalTransactions.toString()
            tvSubscriptionExpense.text = String.format("¥%.2f", stats.subscriptionExpense)
        }
    }

    private fun updateBarChart(monthlyData: List<Pair<YearMonth, Double>>) {
        if (monthlyData.isEmpty()) return

        val entries = monthlyData.mapIndexed { index, (_, amount) ->
            BarEntry(index.toFloat(), amount.toFloat())
        }

        val dataSet = BarDataSet(entries, "月度支出").apply {
            color = ContextCompat.getColor(requireContext(), R.color.primary)
            valueTextSize = 10f
        }

        binding.barChart.apply {
            data = BarData(dataSet)
            xAxis.valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    val index = value.toInt()
                    return if (index in monthlyData.indices) {
                        monthlyData[index].first.format(DateTimeFormatter.ofPattern("MM月"))
                    } else ""
                }
            }
            invalidate()
            animateY(1000)
        }
    }

    private fun updatePieChart(categoryData: Map<String, Double>) {
        if (categoryData.isEmpty()) return

        val entries = categoryData.map { (category, amount) ->
            PieEntry(amount.toFloat(), category)
        }

        val colors = listOf(
            ContextCompat.getColor(requireContext(), R.color.primary),
            ContextCompat.getColor(requireContext(), R.color.secondary),
            ContextCompat.getColor(requireContext(), R.color.tertiary),
            ContextCompat.getColor(requireContext(), R.color.error),
            ContextCompat.getColor(requireContext(), R.color.success)
        )

        val dataSet = PieDataSet(entries, "支出类型").apply {
            this.colors = colors
            valueTextSize = 12f
            valueTextColor = Color.WHITE
        }

        binding.pieChart.apply {
            data = PieData(dataSet)
            invalidate()
            animateY(1000)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
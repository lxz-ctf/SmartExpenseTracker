package com.example.smartexpensetracker.data.database

import androidx.room.*
import com.example.smartexpensetracker.data.model.Subscription
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

@Dao
interface SubscriptionDao {
    @Query("SELECT * FROM subscriptions ORDER BY createdAt DESC")
    fun getAllSubscriptions(): Flow<List<Subscription>>

    @Query("SELECT * FROM subscriptions WHERE isActive = 1 ORDER BY createdAt DESC")
    fun getActiveSubscriptions(): Flow<List<Subscription>>

    @Query("SELECT * FROM subscriptions WHERE isActive = 1 AND startDate <= :date AND :date <= DATE(startDate, '+' || durationMonths || ' months')")
    suspend fun getActiveSubscriptionsForDate(date: LocalDate): List<Subscription>

    @Query("SELECT * FROM subscriptions WHERE id = :subscriptionId")
    suspend fun getSubscriptionById(subscriptionId: Long): Subscription?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubscription(subscription: Subscription): Long

    @Update
    suspend fun updateSubscription(subscription: Subscription)

    @Delete
    suspend fun deleteSubscription(subscription: Subscription)

    @Query("DELETE FROM subscriptions WHERE id = :subscriptionId")
    suspend fun deleteSubscriptionById(subscriptionId: Long)

    @Query("UPDATE subscriptions SET isActive = 0 WHERE id = :subscriptionId")
    suspend fun deactivateSubscription(subscriptionId: Long)
}
package com.example.smartexpensetracker.data.repository

import com.example.smartexpensetracker.data.database.SubscriptionDao
import com.example.smartexpensetracker.data.model.Subscription
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

class SubscriptionRepository(private val subscriptionDao: SubscriptionDao) {

    fun getAllSubscriptions(): Flow<List<Subscription>> = subscriptionDao.getAllSubscriptions()

    fun getActiveSubscriptions(): Flow<List<Subscription>> = subscriptionDao.getActiveSubscriptions()

    suspend fun getActiveSubscriptionsForDate(date: LocalDate): List<Subscription> {
        return subscriptionDao.getActiveSubscriptionsForDate(date)
    }

    suspend fun insertSubscription(subscription: Subscription): Long {
        return subscriptionDao.insertSubscription(subscription)
    }

    suspend fun updateSubscription(subscription: Subscription) {
        subscriptionDao.updateSubscription(subscription)
    }

    suspend fun deleteSubscription(subscription: Subscription) {
        subscriptionDao.deleteSubscription(subscription)
    }

    suspend fun deleteSubscriptionById(subscriptionId: Long) {
        subscriptionDao.deleteSubscriptionById(subscriptionId)
    }

    suspend fun deactivateSubscription(subscriptionId: Long) {
        subscriptionDao.deactivateSubscription(subscriptionId)
    }

    suspend fun getSubscriptionById(subscriptionId: Long): Subscription? {
        return subscriptionDao.getSubscriptionById(subscriptionId)
    }

    /**
     * Calculate daily amortization amount for all active subscriptions on a given date
     */
    suspend fun calculateDailyAmortization(date: LocalDate): Double {
        val activeSubscriptions = getActiveSubscriptionsForDate(date)
        return activeSubscriptions.sumOf { it.dailyAmount }
    }
}
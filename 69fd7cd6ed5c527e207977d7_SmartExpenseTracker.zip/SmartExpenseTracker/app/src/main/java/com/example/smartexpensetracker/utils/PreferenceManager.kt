package com.example.smartexpensetracker.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit

class PreferenceManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    // API Settings
    fun getApiKey(): String? = prefs.getString(KEY_API_KEY, null)
    
    fun setApiKey(apiKey: String) {
        prefs.edit { putString(KEY_API_KEY, apiKey) }
    }

    fun getApiBaseUrl(): String? = prefs.getString(KEY_API_BASE_URL, "https://api.openai.com/v1")
    
    fun setApiBaseUrl(url: String) {
        prefs.edit { putString(KEY_API_BASE_URL, url) }
    }

    fun getModel(): String? = prefs.getString(KEY_MODEL, "gpt-4o-mini")
    
    fun setModel(model: String) {
        prefs.edit { putString(KEY_MODEL, model) }
    }

    // Screenshot Monitoring
    fun isScreenshotMonitoringEnabled(): Boolean = prefs.getBoolean(KEY_SCREENSHOT_MONITORING, true)
    
    fun setScreenshotMonitoringEnabled(enabled: Boolean) {
        prefs.edit { putBoolean(KEY_SCREENSHOT_MONITORING, enabled) }
    }

    // Monthly Notification
    fun isMonthlyNotificationEnabled(): Boolean = prefs.getBoolean(KEY_MONTHLY_NOTIFICATION, true)
    
    fun setMonthlyNotificationEnabled(enabled: Boolean) {
        prefs.edit { putBoolean(KEY_MONTHLY_NOTIFICATION, enabled) }
    }

    // First Launch
    fun isFirstLaunch(): Boolean = prefs.getBoolean(KEY_FIRST_LAUNCH, true)
    
    fun setFirstLaunchCompleted() {
        prefs.edit { putBoolean(KEY_FIRST_LAUNCH, false) }
    }

    // Clear all
    fun clear() {
        prefs.edit { clear() }
    }

    companion object {
        private const val PREF_NAME = "smart_expense_prefs"
        private const val KEY_API_KEY = "api_key"
        private const val KEY_API_BASE_URL = "api_base_url"
        private const val KEY_MODEL = "model"
        private const val KEY_SCREENSHOT_MONITORING = "screenshot_monitoring"
        private const val KEY_MONTHLY_NOTIFICATION = "monthly_notification"
        private const val KEY_FIRST_LAUNCH = "first_launch"
    }
}
package com.example.smartexpensetracker.ui.subscription

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.smartexpensetracker.data.model.Subscription
import com.example.smartexpensetracker.databinding.ItemSubscriptionBinding
import com.example.smartexpensetracker.utils.DateUtils

class SubscriptionAdapter(
    private val onItemClick: (Subscription) -> Unit
) : ListAdapter<Subscription, SubscriptionAdapter.SubscriptionViewHolder>(SubscriptionDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SubscriptionViewHolder {
        val binding = ItemSubscriptionBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return SubscriptionViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SubscriptionViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    fun getItem(position: Int): Subscription = currentList[position]

    inner class SubscriptionViewHolder(
        private val binding: ItemSubscriptionBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onItemClick(getItem(position))
                }
            }
        }

        fun bind(subscription: Subscription) {
            binding.apply {
                tvName.text = subscription.name
                tvAmount.text = String.format("¥%.2f", subscription.amount)
                tvDuration.text = "${subscription.durationMonths} 个月"
                tvDailyAmount.text = String.format("日均 ¥%.2f", subscription.dailyAmount)
                
                val remainingDays = DateUtils.getDaysRemaining(subscription.endDate)
                tvRemaining.text = if (remainingDays > 0) {
                    "剩余 $remainingDays 天"
                } else {
                    "已到期"
                }

                // Visual indicator for active/inactive
                root.alpha = if (subscription.isActive) 1f else 0.5f
            }
        }
    }

    class SubscriptionDiffCallback : DiffUtil.ItemCallback<Subscription>() {
        override fun areItemsTheSame(oldItem: Subscription, newItem: Subscription): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Subscription, newItem: Subscription): Boolean {
            return oldItem == newItem
        }
    }
}
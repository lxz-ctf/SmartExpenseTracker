package com.example.smartexpensetracker.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.smartexpensetracker.databinding.FragmentSettingsBinding
import com.example.smartexpensetracker.service.DailyAmortizationWorker
import com.example.smartexpensetracker.service.MonthlyNotificationReceiver
import com.example.smartexpensetracker.service.ScreenshotMonitorService
import com.example.smartexpensetracker.utils.PreferenceManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private lateinit var preferenceManager: PreferenceManager

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        preferenceManager = PreferenceManager(requireContext())
        
        loadSettings()
        setupListeners()
    }

    private fun loadSettings() {
        binding.apply {
            etApiKey.setText(preferenceManager.getApiKey() ?: "")
            etBaseUrl.setText(preferenceManager.getApiBaseUrl() ?: "https://api.openai.com/v1")
            etModel.setText(preferenceManager.getModel() ?: "gpt-4o-mini")
            
            switchScreenshotMonitoring.isChecked = preferenceManager.isScreenshotMonitoringEnabled()
            switchMonthlyNotification.isChecked = preferenceManager.isMonthlyNotificationEnabled()
        }
    }

    private fun setupListeners() {
        binding.apply {
            btnSaveApiSettings.setOnClickListener {
                saveApiSettings()
            }

            switchScreenshotMonitoring.setOnCheckedChangeListener { _, isChecked ->
                preferenceManager.setScreenshotMonitoringEnabled(isChecked)
                if (isChecked) {
                    ScreenshotMonitorService.startService(requireContext())
                    Snackbar.make(root, "截图监听已开启", Snackbar.LENGTH_SHORT).show()
                } else {
                    ScreenshotMonitorService.stopService(requireContext())
                    Snackbar.make(root, "截图监听已关闭", Snackbar.LENGTH_SHORT).show()
                }
            }

            switchMonthlyNotification.setOnCheckedChangeListener { _, isChecked ->
                preferenceManager.setMonthlyNotificationEnabled(isChecked)
                if (isChecked) {
                    MonthlyNotificationReceiver.scheduleMonthlyNotification(requireContext())
                } else {
                    MonthlyNotificationReceiver.cancelMonthlyNotification(requireContext())
                }
            }

            btnRequestOverlayPermission.setOnClickListener {
                requestOverlayPermission()
            }

            btnClearData.setOnClickListener {
                showClearDataConfirmation()
            }

            btnAbout.setOnClickListener {
                showAboutDialog()
            }
        }
    }

    private fun saveApiSettings() {
        binding.apply {
            val apiKey = etApiKey.text.toString().trim()
            val baseUrl = etBaseUrl.text.toString().trim()
            val model = etModel.text.toString().trim()

            if (apiKey.isBlank()) {
                etApiKey.error = "请输入API密钥"
                return
            }

            preferenceManager.setApiKey(apiKey)
            preferenceManager.setApiBaseUrl(baseUrl)
            preferenceManager.setModel(model)

            Snackbar.make(root, "API设置已保存", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(requireContext())) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${requireContext().packageName}")
            )
            startActivity(intent)
        } else {
            Snackbar.make(binding.root, "已有悬浮窗权限", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun showClearDataConfirmation() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("清除所有数据")
            .setMessage("确定要删除所有记账记录和订阅信息吗？此操作不可恢复。")
            .setPositiveButton("清除") { _, _ ->
                clearAllData()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun clearAllData() {
        // Clear database
        val database = com.example.smartexpensetracker.data.database.AppDatabase.getDatabase(requireContext())
        Thread {
            database.clearAllTables()
        }.start()

        // Clear preferences except API settings
        val apiKey = preferenceManager.getApiKey()
        val baseUrl = preferenceManager.getApiBaseUrl()
        val model = preferenceManager.getModel()
        
        preferenceManager.clear()
        
        apiKey?.let { preferenceManager.setApiKey(it) }
        baseUrl?.let { preferenceManager.setApiBaseUrl(it) }
        model?.let { preferenceManager.setModel(it) }

        Snackbar.make(binding.root, "所有数据已清除", Snackbar.LENGTH_LONG).show()
    }

    private fun showAboutDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("关于智能记账助手")
            .setMessage(
                "版本: 1.0.0\n\n" +
                "功能:\n" +
                "• 自动检测截图并识别金额\n" +
                "• AI大模型智能识别\n" +
                "• 会员订阅管理\n" +
                "• 自动均摊订阅费用\n" +
                "• 月度支出统计\n\n" +
                "使用AI识别需要配置API密钥"
            )
            .setPositiveButton("确定", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
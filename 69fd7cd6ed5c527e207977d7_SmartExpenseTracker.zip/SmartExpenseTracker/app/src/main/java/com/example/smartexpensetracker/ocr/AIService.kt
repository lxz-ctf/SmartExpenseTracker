package com.example.smartexpensetracker.ocr

import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import java.util.Base64
import java.util.concurrent.TimeUnit

class AIService {

    private val gson = Gson()
    private val client: OkHttpClient

    init {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    data class AIConfig(
        val apiKey: String,
        val baseUrl: String = "https://api.openai.com/v1",
        val model: String = "gpt-4o-mini"
    )

    data class ChatRequest(
        val model: String,
        val messages: List<Message>,
        val max_tokens: Int = 500,
        val temperature: Double = 0.1
    )

    data class Message(
        val role: String,
        val content: List<Content>
    )

    data class Content(
        val type: String,
        val text: String? = null,
        @SerializedName("image_url")
        val imageUrl: ImageUrl? = null
    )

    data class ImageUrl(
        val url: String
    )

    data class ChatResponse(
        val choices: List<Choice>
    )

    data class Choice(
        val message: ResponseMessage
    )

    data class ResponseMessage(
        val content: String
    )

    /**
     * Recognize amount from screenshot using AI vision model
     */
    suspend fun recognizeAmount(imageBase64: String, config: AIConfig): RecognitionResult {
        return try {
            val prompt = """
                这是一张支付截图。请识别其中的支付金额（人民币）。
                只返回纯数字金额，不要包含任何其他文字。
                如果没有找到金额，返回 "NOT_FOUND"。
                例如：
                - 如果看到 "¥123.45" 或 "123.45元"，返回 "123.45"
                - 如果看到 "总计: ¥1,234.56"，返回 "1234.56"
                - 如果没有支付金额，返回 "NOT_FOUND"
            """.trimIndent()

            val request = ChatRequest(
                model = config.model,
                messages = listOf(
                    Message(
                        role = "user",
                        content = listOf(
                            Content(type = "text", text = prompt),
                            Content(
                                type = "image_url",
                                imageUrl = ImageUrl(url = "data:image/jpeg;base64,$imageBase64")
                            )
                        )
                    )
                )
            )

            val requestBody = gson.toJson(request).toRequestBody("application/json".toMediaType())

            val httpRequest = Request.Builder()
                .url("${config.baseUrl}/chat/completions")
                .addHeader("Authorization", "Bearer ${config.apiKey}")
                .addHeader("Content-Type", "application/json")
                .post(requestBody)
                .build()

            client.newCall(httpRequest).execute().use { response ->
                if (!response.isSuccessful) {
                    return RecognitionResult.Error("API请求失败: ${response.code}")
                }

                val responseBody = response.body?.string()
                    ?: return RecognitionResult.Error("响应为空")

                val chatResponse = gson.fromJson(responseBody, ChatResponse::class.java)
                val content = chatResponse.choices.firstOrNull()?.message?.content?.trim()
                    ?: return RecognitionResult.Error("无法解析响应")

                if (content == "NOT_FOUND") {
                    RecognitionResult.NotFound
                } else {
                    val amount = content.replace(",", "").toDoubleOrNull()
                    if (amount != null && amount > 0) {
                        RecognitionResult.Success(amount)
                    } else {
                        RecognitionResult.Error("无法解析金额: $content")
                    }
                }
            }
        } catch (e: Exception) {
            RecognitionResult.Error("识别失败: ${e.message}")
        }
    }

    /**
     * Alternative: Use local regex-based extraction as fallback
     */
    fun extractAmountWithRegex(text: String): Double? {
        // Common patterns for Chinese currency
        val patterns = listOf(
            "¥\\s*([0-9,]+\\.?[0-9]{0,2})".toRegex(),
            "￥\\s*([0-9,]+\\.?[0-9]{0,2})".toRegex(),
            "([0-9,]+\\.?[0-9]{0,2})\\s*元".toRegex(),
            "实付[：:]\\s*([0-9,]+\\.?[0-9]{0,2})".toRegex(),
            "合计[：:]\\s*([0-9,]+\\.?[0-9]{0,2})".toRegex(),
            "总价[：:]\\s*([0-9,]+\\.?[0-9]{0,2})".toRegex(),
            "金额[：:]\\s*([0-9,]+\\.?[0-9]{0,2})".toRegex(),
            "支付[：:]\\s*([0-9,]+\\.?[0-9]{0,2})".toRegex()
        )

        for (pattern in patterns) {
            val match = pattern.find(text)
            if (match != null) {
                val amountStr = match.groupValues[1].replace(",", "")
                return amountStr.toDoubleOrNull()
            }
        }

        // Last resort: find any number that looks like a price
        val generalPattern = "([0-9]+\\.[0-9]{2})".toRegex()
        val matches = generalPattern.findAll(text).toList()
        
        // Return the largest amount found (usually the total)
        return matches.mapNotNull { it.groupValues[1].toDoubleOrNull() }.maxOrNull()
    }

    sealed class RecognitionResult {
        data class Success(val amount: Double) : RecognitionResult()
        object NotFound : RecognitionResult()
        data class Error(val message: String) : RecognitionResult()
    }
}
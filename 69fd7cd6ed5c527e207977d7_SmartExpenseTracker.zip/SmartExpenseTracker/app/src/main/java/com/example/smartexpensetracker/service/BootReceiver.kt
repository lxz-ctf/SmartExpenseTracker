package com.example.smartexpensetracker.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.smartexpensetracker.utils.PreferenceManager

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Log.d(TAG, "Boot completed, checking if service should start")
            
            val preferenceManager = PreferenceManager(context)
            if (preferenceManager.isScreenshotMonitoringEnabled()) {
                Log.d(TAG, "Starting screenshot monitor service")
                ScreenshotMonitorService.startService(context)
            }
            
            // Schedule monthly notification
            MonthlyNotificationReceiver.scheduleMonthlyNotification(context)
        }
    }

    companion object {
        private const val TAG = "BootReceiver"
    }
}
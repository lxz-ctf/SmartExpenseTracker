package com.example.smartexpensetracker.service

import android.content.Context
import android.util.Log
import androidx.work.*
import com.example.smartexpensetracker.data.database.AppDatabase
import com.example.smartexpensetracker.data.model.Expense
import com.example.smartexpensetracker.data.repository.ExpenseRepository
import com.example.smartexpensetracker.data.repository.SubscriptionRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.concurrent.TimeUnit

class DailyAmortizationWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    private val expenseRepository = ExpenseRepository(AppDatabase.getDatabase(context).expenseDao())
    private val subscriptionRepository = SubscriptionRepository(AppDatabase.getDatabase(context).subscriptionDao())

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Running daily amortization at ${LocalDateTime.now()}")
            
            val today = LocalDate.now()
            val activeSubscriptions = subscriptionRepository.getActiveSubscriptionsForDate(today)
            
            var totalAmortization = 0.0
            
            for (subscription in activeSubscriptions) {
                val dailyAmount = subscription.dailyAmount
                totalAmortization += dailyAmount
                
                // Create expense record for this subscription's daily share
                val expense = Expense(
                    amount = dailyAmount,
                    description = "${subscription.name} - 每日均摊",
                    date = today,
                    isAmortization = true,
                    subscriptionId = subscription.id
                )
                
                expenseRepository.insertExpense(expense)
                Log.d(TAG, "Created amortization expense for ${subscription.name}: ¥$dailyAmount")
            }
            
            Log.d(TAG, "Total daily amortization: ¥$totalAmortization")
            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "Error in daily amortization", e)
            Result.retry()
        }
    }

    companion object {
        private const val TAG = "DailyAmortization"
        private const val WORK_NAME = "daily_amortization"

        fun schedule(context: Context) {
            val workManager = WorkManager.getInstance(context)
            
            // Calculate initial delay to midnight
            val now = LocalDateTime.now()
            val midnight = LocalDateTime.of(LocalDate.now().plusDays(1), LocalTime.MIDNIGHT)
            val initialDelay = Duration.between(now, midnight).toMinutes()

            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                .build()

            val dailyWorkRequest = PeriodicWorkRequestBuilder<DailyAmortizationWorker>(1, TimeUnit.DAYS)
                .setInitialDelay(initialDelay, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .addTag(WORK_NAME)
                .build()

            workManager.enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                dailyWorkRequest
            )

            Log.d(TAG, "Scheduled daily amortization work with ${initialDelay}min initial delay")
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}